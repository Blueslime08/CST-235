package Data;

import java.util.List;

import Models.Product;

public interface ProductDataInterface {

	 public List<Product> findAll();
	 public Product findByID(int productID);
	 public boolean updateProduct(Product product);
	 public boolean deleteProduct(Product prodyct);
	 
	 public boolean newProduct(Product product);
}
