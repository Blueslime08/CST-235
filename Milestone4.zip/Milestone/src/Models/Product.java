package Models;

import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.validation.constraints.NotNull;

@ApplicationScoped
@ManagedBean
public class Product {
	
	private int Id;
	
	@NotNull(message = "Please enter car make")
	private String make = "";
	
	@NotNull(message = "Please enter car model")
	private String model = "";
	
	@NotNull(message = "Please enter car year")
	private int year = 0;
	
	@NotNull(message = "Please enter car mileage")
	private float mileage = 0;
	
	@NotNull(message = "Please enter car color")
	private String color = "";
	
	@NotNull(message = "Please enter car color")
	private double price = 0;
	
	
	
	public Product() {
		Id = 0;
		make = "";
		model = "";
		year = 0;
		mileage = 0;
		color = "";
		price = 0;
	}

	public Product(int Id, String make, String model, int year, float mileage, String color,  double price) {
		this.Id = Id;
		this.make = make;
		this.model = model;
		this.year = year;
		this.mileage = mileage;
		this.color = color;
		this.price = price;
		
	}

	public int getId() {
		return Id;
	}

	public void setId(int Id) {
		this.Id = Id;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public float getMileage() {
		return mileage;
	}

	public void setMileage(float mileage) {
		this.mileage = mileage;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
}
