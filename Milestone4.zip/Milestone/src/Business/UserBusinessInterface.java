package Business;

import Models.User;

public interface UserBusinessInterface {

	public boolean Authenticate(User user);
	
	public boolean Registration(User user);
}
