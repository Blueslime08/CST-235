package controllers;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import Business.UserBusinessInterface;
import Models.User;

@ManagedBean
@ViewScoped

public class LoginController {

		@Inject
		UserBusinessInterface service;
	
	public String login(User user)
	{
		if(service.Authenticate(user))
			return "index.xhtml";
		else
			return "LoginFaild.xhtml";
			
		
	}
	
	public String Registration(User user)
	{
		if(service.Registration(user))
			return "index.xhtml";
		else
			return "RegistrationForm.xhtml";
	}
	
	public String logOut(User user)
	{
		FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
		
		return "LoginForm.xhtml?faces-redirect=true";
	}
	
	

}
