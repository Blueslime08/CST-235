package controllers;


import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;

import beans.Car;

@ManagedBean
public class ProductController {

	public String onSubmit() {
		
		//get the user value from the input form
		FacesContext context = FacesContext.getCurrentInstance();
		Car car = context.getApplication().evaluateExpressionGet(context, "#{car}", Car.class);
				
		//show the user object in the console log
		System.out.println("You clicked something");
		System.out.println("The Car ID is " + car.getId());
		System.out.println("The Car Make is " + car.getMake());
		System.out.println("The Car Model is " + car.getModel());
		System.out.println("The Car Year is " + car.getYear());
		System.out.println("The Car Mileage is " + car.getMileage());
		System.out.println("The Car Color is " + car.getColor());
		
		//put the user object into the post request
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("car", car);
		//return the next page
		return "NewCarRegister.xhtml";
				
		
	}
}
