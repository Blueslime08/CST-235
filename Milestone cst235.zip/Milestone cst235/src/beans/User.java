package beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.validation.constraints.NotNull;
//import javax.validation.constraints.Null;
import javax.validation.constraints.Size;

@ViewScoped
@ManagedBean
public class User {
	
	@NotNull(message = "Please enter first name")
	@Size(min=2, max=15)
	private String firstName;
	
	@NotNull(message = "Please enter last name")
	@Size(min=2, max=15)
	private String lastName;
	
	@NotNull(message = "Please enter email")
	private String email;
	
	@NotNull(message = "Please enter address")
	private String address;
	
	@NotNull(message = "Please enter phone")
	private String phone;
	
	@NotNull(message = "Please enter username")
	private String username;
	
	@NotNull(message = "Please enter password")
	private String password;
	

	public User() {
		
		firstName = "James";
		lastName = "Rawe";
		email = "email.com";
		address = "address";
		phone = "phone";
		username = "JRawe";
		password = "password";
		
	}
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


}
