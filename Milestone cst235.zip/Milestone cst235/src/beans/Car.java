package beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.validation.constraints.NotNull;
//import javax.validation.constraints.Null;
import javax.validation.constraints.Size;

@ViewScoped
@ManagedBean
public class Car {
	
	private int id;
	
	@NotNull(message = "Please enter car make")
	private String make = "";
	
	@NotNull(message = "Please enter car model")
	private String model = "";
	
	@NotNull(message = "Please enter car year")
	private int year = 0;
	
	@NotNull(message = "Please enter car mileage")
	private float mileage = 0;
	
	@NotNull(message = "Please enter car color")
	private String color = "";
	
	public Car()
	{
		id = 0;
		make = "";
		model = "";
		year = 0;
		mileage = 0;
		color = "";
	}
	
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public float getMileage() {
		return mileage;
	}
	public void setMileage(float mileage) {
		this.mileage = mileage;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
}
