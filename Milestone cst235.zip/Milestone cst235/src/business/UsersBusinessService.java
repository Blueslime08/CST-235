package business;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import beans.Car;

@Stateless
@Local(OrdersBusinessInterface.class)
@Alternative
public class UsersBusinessService implements OrdersBusinessInterface {

	
	
	@Override
	public void test() {
		System.out.println("Printing from @UsersBusinessService test method");
	}

	public UsersBusinessService(){
		//user information will go here when it comes time to keep a list of users
	}
	
	@Override
	public List<Car> getOrders() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setOrders(List<Car> car) {
		// TODO Auto-generated method stub
		
	}

}
