package business;

import java.util.List;

import javax.ejb.Local;
import beans.Car;

@Local
public interface OrdersBusinessInterface {
	public void test();
	public List<Car> getOrders();
	public void setOrders(List<Car> car);
}
