package business;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import beans.Car;


@Stateless
@Local(OrdersBusinessInterface.class)
@Alternative
public class OrdersBusinessService implements OrdersBusinessInterface {

	List<Car> car = new ArrayList<Car>();
	
	@Override
	public void test() {
		System.out.println("Printing from @OrdersBusinessService test method");
	}

	public OrdersBusinessService(){
		
	}
	
	@Override
	public List<Car> getOrders() {
		// TODO Auto-generated method stub
		return car;
	}

	@Override
	public void setOrders(List<Car> car) {
		// TODO Auto-generated method stub
		this.car = car;
	}

}
