package Models;

import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

@ViewScoped
@ManagedBean
public class SearchID {


	int id;
	
	public SearchID() {
		this.id = this.getId();
	}
	
	public SearchID(int id) {
		this.id = id;
	}
	
	

	/**
	 * @return the iD
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param iD the iD to set
	 */
	public void setId(int id) {
		this.id = id;
	}
}
