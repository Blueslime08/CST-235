package Data;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import Models.User;

public class SecurityDAO implements DataAccessInterface{

	public boolean findBylogin(User user)
	{
		Connection conn = null;
		String url = "jdbc:postgresql://localhost:5432/Cars";
		String username = "postgres";
		String password = "root";
		
		
		String sql = "SELECT * FROM mydb.\"Users\" where \"USERNAME\" = '" + user.getUserName()+ "' AND \"PASSWORD\" = '"+ user.getPassword()+"'";
		
		try {
		System.out.println("I am in SecurityDAO.findBylogin");
		System.out.println(user.getUserName());
		System.out.println(user.getPassword());
		conn = DriverManager.getConnection(url, username, password);
		Statement stmt = conn.createStatement();
		ResultSet res = stmt.executeQuery(sql);
		if (res.next())
		{
			System.out.println("login success");
			return true;
		}
		}
		
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		finally
		{
			if(conn != null) {
				try {
					conn.close();
				}
				catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return false;
	}
	
	public boolean Registration(User user)
	{
		Connection conn = null;
		String url = "jdbc:postgresql://localhost:5432/Cars";
		String username = "postgres";
		String password = "root";
		String sql = "INSERT INTO mydb.\"Users\"(\n"
				+ "\"FIRSTNAME\", \"LASTNAME\", \"EMAIL\", \"PHONENUMBER\", \"USERNAME\", \"PASSWORD\", \"ROLE\")\n"
				+ "	VALUES (?, ?, ?, ?, ?, ?, ?)";

		try
		{
			conn = DriverManager.getConnection(url, username, password);
			
			PreparedStatement prepared = conn.prepareStatement(sql);
			prepared.setString(1, user.getFirstName());
			prepared.setString(2, user.getLastName());
			prepared.setString(3, user.getEmail());
			prepared.setString(4, user.getPhone());
			prepared.setString(5, user.getUserName());
			prepared.setString(6, user.getPassword());
			prepared.setInt(7, 2);
			prepared.executeUpdate();
			
			return true;
			
		}
		
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			if(conn != null) {
				try {
					conn.close();
				}
				catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return false;
	}
}
