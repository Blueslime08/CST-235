package Business;

import java.util.List;

import Models.Product;

public interface ProductBusinessInterface {

	public List<Product> findAll();
	public Product findByID(int productID);
	public boolean updateProduct(Product product);
	public boolean deleteProduct(Product product);
	
	public boolean newProduct(Product product);
}
